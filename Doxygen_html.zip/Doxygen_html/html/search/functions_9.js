var searchData=
[
  ['ncharinfile_80',['nCharInFile',['../function_8h.html#a42df0f0aef483eb829ad17517fc09846',1,'function.h']]]
];
