var searchData=
[
  ['element_85',['Element',['../queue_8h.html#aed98d73ee26a4beb54eaea48f35f8694',1,'queue.h']]]
];
