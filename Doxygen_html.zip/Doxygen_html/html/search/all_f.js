var searchData=
[
  ['unqueue_42',['unqueue',['../queue_8h.html#adc8a9b2a1a31197ff80fdc9cf0ff9898',1,'queue.h']]]
];
